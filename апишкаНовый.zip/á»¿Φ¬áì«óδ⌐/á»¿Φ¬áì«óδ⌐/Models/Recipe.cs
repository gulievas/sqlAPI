﻿using System;
using System.Collections.Generic;

namespace апишкаНовый.Models
{
    public partial class Recipe
    {
        public int RecipeId { get; set; }
        public string Name { get; set; } = null!;
        public string Ingredients { get; set; } = null!;
        public string Steps { get; set; } = null!;
        public int UserId { get; set; }
        public int ProductId { get; set; }

        public virtual Product Product { get; set; } = null!;
        public virtual Uuser User { get; set; } = null!;
    }
}
