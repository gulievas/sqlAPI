﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using апишкаНовый.Models;

namespace User
{
    [Route("api/[controller]")]
    [ApiController]
    [Route("api/users")]
    public class UusersController : ControllerBase
    {
        private readonly Гулиева_APIContext _context;

        public UusersController(Гулиева_APIContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        // Метод для получения всех пользователей
        [HttpGet]
        public IActionResult GetAll()
        {
            List<Uuser> users = _context.Uusers.ToList();
            return Ok(users);
        }

        // Метод для получения пользователя по идентификатору
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            Uuser user = _context.Uusers.Find(id);

            if (user == null)
            {
                return NotFound("User not found");
            }

            return Ok(user);
        }

        // Метод для добавления нового пользователя
        [HttpPost]
        public IActionResult Add(Uuser user)
        {
            _context.Uusers.Add(user);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = user.UserId }, user);
        }

        // Метод для обновления информации о пользователе по идентификатору
        [HttpPut("{id}")]
        public IActionResult Update(int id, Uuser user)
        {
            if (id != user.UserId)
            {
                return BadRequest("Invalid user ID");
            }

            _context.Entry(user).State = EntityState.Modified;
            _context.SaveChanges();

            return Ok(user);
        }

        // Метод для удаления пользователя по идентификатору
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Uuser user = _context.Uusers.Find(id);

            if (user == null)
            {
                return NotFound("User not found");
            }

            _context.Uusers.Remove(user);
            _context.SaveChanges();

            return Ok(user);
        }
    }
}