﻿namespace айпишкинКласс
{
    public class Class1
    {

    }
}